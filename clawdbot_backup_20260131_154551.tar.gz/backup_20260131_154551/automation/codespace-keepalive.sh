#!/bin/bash
# Codespace 保活脚本
# 每 5 分钟发送一次请求到自身，保持活跃

LOG_FILE="/home/codespace/codespace-keepalive.log"
CODESSPACE_URL="https://automatic-space-halibut-qgjx69w7gwr2x9wx-18789.app.github.dev"

log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1" >> "$LOG_FILE"
}

log "🚀 Codespace 保活脚本启动"

while true; do
    # 发送请求到自身（通过公网URL）
    curl -s -o /dev/null -w "%{http_code}" "$CODESSPACE_URL" >> "$LOG_FILE" 2>&1
    
    # 同时访问内部接口
    curl -s -o /dev/null http://localhost:3001
    curl -s -o /dev/null http://127.0.0.1:18789
    
    log "💓 心跳发送完成"
    
    # 每 5 分钟运行一次
    sleep 300
done
