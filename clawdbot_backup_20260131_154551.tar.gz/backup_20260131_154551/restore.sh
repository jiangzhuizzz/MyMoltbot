#!/bin/bash
# Clawdbot 恢复脚本
# 在新设备上运行

BACKUP_DIR=$(dirname "$0")
DATE=$(date '+%Y-%m-%d %H:%M')

log() {
    echo "[$(date '+%Y-%m-%d %H:%M:%S')] $1"
}

log "🚀 开始恢复 Clawdbot..."

# 1. 恢复核心记忆文件
log "📦 恢复核心记忆文件..."
cp -r "$BACKUP_DIR/core/"* /home/codespace/clawd/
log "✅ 核心记忆文件已恢复"

# 2. 恢复项目文件
log "📦 恢复项目文件..."
cd /workspaces
tar -xzf "$BACKUP_DIR/project/mymoltbot.tar.gz"
log "✅ 项目文件已恢复"

# 3. 恢复自动化系统
log "📦 恢复自动化系统..."
cp -r "$BACKUP_DIR/automation/"* /home/codespace/clawd/
log "✅ 自动化系统已恢复"

# 4. 恢复配置文件
log "📦 恢复配置文件..."
cp -r "$BACKUP_DIR/config/"* ~/.clawdbot/
log "✅ 配置文件已恢复"

# 5. 设置权限
log "🔧 设置权限..."
chmod +x /home/codespace/clawd/daily-report/*.sh
chmod +x /home/codespace/clawd/product-collector/**/*.sh
chmod +x /home/codespace/clawd/wechat-collector/**/*.sh
chmod +x /home/codespace/clawd/codespace-keepalive.sh

log "✅ 权限已设置"

# 6. 安装依赖
log "📦 安装依赖..."
cd /workspaces/MyMoltbot && npm install
cd /home/codespace/clawd/daily-report && pip3 install -r requirements.txt 2>/dev/null || true
cd /home/codespace/clawd/product-collector && pip3 install -r requirements.txt 2>/dev/null || true

log "✅ 依赖已安装"

log ""
log "=========================================="
log "    恢复完成！"
log "=========================================="
log ""
log "下一步操作:"
log "1. 重启 Clawdbot: clawdbot gateway restart"
log "2. 验证系统: clawdbot status"
log "3. 测试自动化: bash /home/codespace/clawd/daily-report/generate-report.py"
log ""
log "建议设置定时任务:"
log "- crontab -e"
log "- 添加: 0 9 * * * /home/codespace/clawd/daily-report/generate-report.py"
log ""
